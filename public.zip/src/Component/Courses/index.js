import Courses from "./Courses";

export default Courses;