import Page404 from "./404";

export default Page404;