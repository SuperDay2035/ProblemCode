import csharpinfo from "./csharpinfo";

export default csharpinfo;