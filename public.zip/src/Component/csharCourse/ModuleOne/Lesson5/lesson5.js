import React from 'react';
import Dashboard from "../Dashboard/Dashboard";

function Lesson5(props) {
    return (
        <div>


            <Dashboard>

                <h1>Lesson 5</h1>

            </Dashboard>


        </div>
    );
}

export default Lesson5;