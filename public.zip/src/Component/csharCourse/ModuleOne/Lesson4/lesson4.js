import React from 'react';
import Dashboard from "../Dashboard/Dashboard";

function Lesson4(props) {
    return (
        <div>

            <Dashboard>

                <h1>Lesson 4</h1>

            </Dashboard>


        </div>
    );
}

export default Lesson4;