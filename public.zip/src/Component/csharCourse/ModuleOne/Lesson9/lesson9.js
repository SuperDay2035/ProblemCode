import React from 'react';
import Dashboard from "../Dashboard/Dashboard";

function Lesson9(props) {
    return (
        <div>


            <Dashboard>

                <h1>Lesson 9</h1>

            </Dashboard>


        </div>
    );
}

export default Lesson9;