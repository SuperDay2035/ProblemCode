import React from 'react';
import Dashboard from "../Dashboard/Dashboard";

function Lesson8(props) {
    return (
        <div>


            <Dashboard>

                <h1>Lesson 8</h1>

            </Dashboard>


        </div>
    );
}

export default Lesson8;