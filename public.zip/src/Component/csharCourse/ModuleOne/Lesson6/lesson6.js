import React from 'react';
import Dashboard from "../Dashboard/Dashboard";

function Lesson6(props) {
    return (
        <div>


            <Dashboard>

                <h1>Lesson 6</h1>

            </Dashboard>


        </div>
    );
}

export default Lesson6;