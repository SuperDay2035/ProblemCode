import React from 'react';
import Dashboard from "../Dashboard/Dashboard";

function Lesson3(props) {
    return (
        <div>


            <Dashboard>

                <h1>Lesson 3</h1>

            </Dashboard>


        </div>
    );
}

export default Lesson3;