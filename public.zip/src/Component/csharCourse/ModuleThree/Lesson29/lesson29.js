import React from 'react';
import Dashboard3 from "../Dashboard/Dashboard3";

function Lesson29(props) {
    return (
        <Dashboard3>

            <h1>Lesson 29</h1>

        </Dashboard3>
    );
}

export default Lesson29;