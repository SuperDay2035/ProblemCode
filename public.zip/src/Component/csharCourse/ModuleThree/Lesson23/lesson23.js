import React from 'react';
import Dashboard3 from "../Dashboard/Dashboard3";

function Lesson23(props) {
    return (
        <Dashboard3>

            <h1>Lesson 23</h1>

        </Dashboard3>
    );
}

export default Lesson23;