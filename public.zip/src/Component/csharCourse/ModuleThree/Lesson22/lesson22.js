import React from 'react';
import Dashboard3 from "../Dashboard/Dashboard3";

function Lesson22(props) {
    return (
        <Dashboard3>

            <h1>Lesson 22</h1>

        </Dashboard3>
    );
}

export default Lesson22;