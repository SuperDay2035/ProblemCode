import React from 'react';
import Dashboard3 from "../Dashboard/Dashboard3";

function Lesson25(props) {
    return (
        <Dashboard3>

            <h1>Lesson 25</h1>

        </Dashboard3>
    );
}

export default Lesson25;