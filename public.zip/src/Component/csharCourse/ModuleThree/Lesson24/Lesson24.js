import React from 'react';
import Dashboard3 from "../Dashboard/Dashboard3";

function Lesson24(props) {
    return (
        <Dashboard3>

            <h1>Lesson 24</h1>

        </Dashboard3>
    );
}

export default Lesson24;