import React from 'react';
import Dashboard2 from "../Dashboard/Dashboard2";

function Lesson14(props) {
    return (
        <div>

            <Dashboard2>

                <h1>Lesson 14</h1>

            </Dashboard2>

        </div>
    );
}

export default Lesson14;